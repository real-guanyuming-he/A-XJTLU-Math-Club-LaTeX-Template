# A XJTLU Math Club LaTeX Template
 A LaTeX template (including packages and .tex templates) initially written to simplify the work of the math club administrators, yet is also intended to be shared to the whole university (or even community)
# Copyright
This package is licensed under the MIT license. Copyright (C) Guanyuming He 2021-2021.
